package com.example.dictionaryapi;

import com.example.dictionaryapi.Models.APIResponse;

public interface OnFetchDataListener {
    void onFetchData(APIResponse apiResponse, String message);
    void onError(String message);
}
